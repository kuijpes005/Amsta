$(function() {
    var appClass = require("app");
    appClass.App.main();
});