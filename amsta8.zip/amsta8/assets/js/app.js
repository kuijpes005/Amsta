define("controllers/controller", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class Controller {
        constructor() {
            this.setup();
        }
    }
    exports.Controller = Controller;
});
define("utils/testutils", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class TestUtils {
        static isThisWorking() {
            return "Test test 123";
        }
    }
    exports.TestUtils = TestUtils;
});
define("components/test-button/test-button", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class TestButton {
        constructor(text) {
            this.text = text;
        }
        setOnClick(callback) {
            this.onClickCallback = callback;
        }
        getView() {
            const template = `<button>${this.text}</button>`;
            return $(template)
                .on("click", (e) => this.onClickCallback(e));
        }
    }
    exports.TestButton = TestButton;
});
define("controllers/maincontroller", ["require", "exports", "controllers/controller", "utils/testutils", "components/test-button/test-button"], function (require, exports, controller_1, testutils_1, test_button_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class MainController extends controller_1.Controller {
        setup() {
            let testButton = new test_button_1.TestButton("Click me");
            testButton.setOnClick((e) => {
                alert(testutils_1.TestUtils.isThisWorking());
                $.get("/views/test.html").done(function (data) {
                    $("#test-button").append(data);
                });
            });
            $("#test-button").append(testButton.getView());
        }
    }
    exports.MainController = MainController;
});
define("models/stapmodel", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class StapModel {
        constructor(title, description, imageUrl) {
            this.title = title;
            this.description = description;
            this.imageUrl = imageUrl;
        }
    }
    exports.StapModel = StapModel;
});
define("models/stappenplanmodel", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class Stappenplan {
        constructor(title, imageUrl) {
            this.title = title;
            this.steps = new Array();
            this.imageUrl = imageUrl;
        }
        addStep(step) {
            this.steps.push(step);
        }
    }
    exports.Stappenplan = Stappenplan;
});
define("controllers/stappenplancontroller", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class StappenplanController {
        constructor(stappenPlan) {
            this.stappenPlan = stappenPlan;
            this.stepIndex = 0;
            this.renderPage();
        }
        renderPage() {
            var self = this;
            $.get("/views/stap.html").done(function (data) {
                $("#body").html(data);
                var step = self.stappenPlan.steps[self.stepIndex];
                if (self.stepIndex < 1) {
                    $("#body #previous").hide();
                }
                else {
                    $("#body #previous").show();
                }
                if (self.stepIndex < self.stappenPlan.steps.length - 1) {
                    $("#body #next").show();
                }
                else {
                    $("#body #next").hide();
                }
                $("#body #title").html(step.title);
                $("#body #description").html(step.description);
                $("#body #image").attr("src", step.imageUrl);
                $("#body #previous").on("click", function () {
                    self.previousStep();
                    self.renderPage();
                    return false;
                });
                $("#body #next").click(function () {
                    self.nextStep();
                    self.renderPage();
                    return false;
                });
                self.setProgressbar();
            });
        }
        previousStep() {
            if (this.stepIndex > 0) {
                this.stepIndex--;
            }
        }
        nextStep() {
            if (this.stepIndex < this.stappenPlan.steps.length - 1) {
                this.stepIndex++;
            }
        }
        setProgressbar() {
            let totalSteps = this.stappenPlan.steps.length;
            let currentStep = this.stepIndex;
            for (let iBullet = 0; iBullet < totalSteps; iBullet++) {
                let bullet = $('<a href="#" data-i="' + iBullet + '"></a>').text(iBullet + 1);
                let segmentSize = iBullet * 100 / (totalSteps - 1);
                bullet.css('left', segmentSize + '%');
                if (iBullet <= currentStep) {
                    bullet.addClass("current");
                }
                if (currentStep > iBullet) {
                    bullet.removeClass("current").addClass("done");
                }
                ;
                $(".progress-bullets").append(bullet);
            }
            let totalSize = (currentStep / (totalSteps - 1) * 100);
            console.log(totalSize);
            $(".progress-bar").css("width", totalSize + "%");
        }
    }
    exports.StappenplanController = StappenplanController;
});
define("controllers/stappenplanoverviewcontroller", ["require", "exports", "controllers/stappenplancontroller"], function (require, exports, stappenplancontroller_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class StappenplanOverviewController {
        constructor(wizards) {
            this.wizards = wizards;
            this.renderPage();
        }
        renderPage() {
            $("#stappenplannen").empty();
            var row = $("<div class=row>");
            for (var i = 0; i < this.wizards.length; i++) {
                var wizard = this.wizards[i];
                var div = $("<div class=col-md-4 >");
                var h3 = $("<h3>")
                    .text(wizard.title)
                    .data("wizard", wizard)
                    .on("click", function () {
                    let controller = new stappenplancontroller_1.StappenplanController($(this).data("wizard"));
                });
                var img = $("<img class=img-thumbnail>")
                    .attr("src", wizard.imageUrl)
                    .data("wizard", wizard)
                    .on("click", function () {
                    let controller = new stappenplancontroller_1.StappenplanController($(this).data("wizard"));
                });
                row.append(div);
                div.append(img);
                div.append(h3);
            }
            $("#stappenplannen").append(row);
        }
    }
    exports.StappenplanOverviewController = StappenplanOverviewController;
});
define("app", ["require", "exports", "models/stappenplanmodel", "models/stapmodel", "controllers/stappenplanoverviewcontroller"], function (require, exports, stappenplanmodel_1, stapmodel_1, stappenplanoverviewcontroller_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    class App {
        static main() {
            var tandenPoetsen = new stappenplanmodel_1.Stappenplan("Tanden poetsen", "assets/img/-1487584015.jpg");
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 1", "Pak een tube tandpasta en uw tandenborstel.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen1.jpg"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 2", "Breng ongeveer 2 centimeter aan tandpasta op uw tandenborstel.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen2.jpg"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 3", "Poets de binnenkant van alle tanden in uw onderkaak.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen3.jpg"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 4", "Poets de buitenkant van alle tanden in uw onderkaak.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen4.gif"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 5", "Poets de bovenkant van alle kiezen in uw onderkaak.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen5.gif"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 6", "Poets de binnenkant van alle tanden in uw bovenkaak.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen6.gif"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 7", "Poets de buitenkant van alle tanden in uw bovenkaak.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen7.gif"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("Stap 8", "Poets de bovenkant van alle kiezen in uw bovenkaak.", "../assets/img/Stappenplanfotos/TandenPoetsen/TandenPoetsen8.gif"));
            tandenPoetsen.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var kledingWassen = new stappenplanmodel_1.Stappenplan("Kleding wassen", "assets/img/15-duurzame-wastips-voor-kleding.jpg");
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 1", "Leg alle vieze bonte kleding in de wasmand.", "../assets/img/Stappenplanfotos/KledingWassen/Mand-stap1.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 2", "Neem de wasmand mee en loop richting de wasmachine.", "../assets/img/Stappenplanfotos/KledingWassen/Wasmachine-stap2.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 3", "Stop de kleding in de wasmachine.", "../assets/img/Stappenplanfotos/KledingWassen/Wasmachine-stap3.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 4", "Sluit de deur van de wasmachine.", "../assets/img/Stappenplanfotos/KledingWassen/Wasmachine-stap4.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 5", "Doe het wasmiddel in het laatje.", "../assets/img/Stappenplanfotos/KledingWassen/Wasmachine-stap5.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 6", "Doe het laatje dicht.", "../assets/img/Stappenplanfotos/KledingWassen/Wasmachine-stap6.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("Stap 7", "Druk op deze knop om te starten met wassen.", "../assets/img/Stappenplanfotos/KledingWassen/Wasmachine-stap7.jpg"));
            kledingWassen.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var plantenWaterGeven = new stappenplanmodel_1.Stappenplan("Planten water geven", "assets/img/watering-can-old-man.jpg");
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 1", "Pak een gieter.", "../assets/img/Stappenplanfotos/PlantenWaterGeven/Gieter.jpg"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 2", "Loop naar de kraan.", "../assets/img/Stappenplanfotos/PlantenWaterGeven/wasbak.jpg"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 3", "Open de kraan en vul de gieter met water.", "../assets/img/Stappenplanfotos/PlantenWaterGeven/KraanOpen.jpg"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 4", "Draai de kraan dicht, zodat er geen water meer uitkomt.", "../assets/img/Stappenplanfotos/PlantenWaterGeven/KraanDicht.jpg"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 5", "Loop naar de planten.", "../assets/img/Stappenplanfotos/PlantenWaterGeven/planten.jpg"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 6", "Geef de planten een beetje water.", "../assets/img/Stappenplanfotos/PlantenWaterGeven/Water-geven.jpg"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("Stap 7", "Als de gieter leeg is, zet de gieter terug op zijn plek", "../assets/img/Stappenplanfotos/PlantenWaterGeven/gieter-plek.png"));
            plantenWaterGeven.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var tafelDekken = new stappenplanmodel_1.Stappenplan("Tafel dekken", "assets/img/img_7297.jpg");
            tafelDekken.addStep(new stapmodel_1.StapModel("Stap 1", "Pak de borden en zet een bord neer op iedere zitplek.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken1.jpg"));
            tafelDekken.addStep(new stapmodel_1.StapModel("Stap 2", "Leg een mes rechts neer naast ieder bord.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken2.jpg"));
            tafelDekken.addStep(new stapmodel_1.StapModel("Stap 3", "Leg een lepel boven ieder bord.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken3.jpg"));
            tafelDekken.addStep(new stapmodel_1.StapModel("Stap 4", "Leg een vork links neer naast ieder bord.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken4.jpg"));
            tafelDekken.addStep(new stapmodel_1.StapModel("Stap 5", "Zet een glas rechtsboven ieder bord.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken5.jpg"));
            tafelDekken.addStep(new stapmodel_1.StapModel("Stap 6", "Leg een servet neer op ieder bord.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken6.jpg"));
            tafelDekken.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var koffieMaken = new stappenplanmodel_1.Stappenplan("Koffie maken", "assets/img/koffiezetten.jpg");
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 1", "Open de waterklep.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken1.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 2", "Vul de koffiekan met water.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken2.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 3", "Giet het water boven in het koffiezetapparaat.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken3.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 4", "Zet de lege kan op het warmhoudplaatje.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken4.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 5", "Plaats het filter in de filterhouder.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken5.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 6", "Doe 2 afgestreken koffieschepjes in het filter.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken6.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 7", "Plaats de deksel op de filterhouder.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken1.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 8", "Zet de filterhouder op de kan.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken2.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 9", "Zet het koffiezetapparaat aan en wacht totdat het koffiezetapparaat klaar is.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken3.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("Stap 10", "Als het klaar is, kan je de koffie in een kopje schenken.", "assets/img/Stappenplanfotos/TafelDekken/TafelDekken4.jpg"));
            koffieMaken.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var sportkleding = new stappenplanmodel_1.Stappenplan("Omkleden om te sporten", "assets/img/sporten-voor-beginners.jpg");
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 1", "Pak uw sportkleding uit de kast.", "assets/img/Stappenplanfotos/sportKleding/kast.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 2", "Trek uw trui uit.", "assets/img/Stappenplanfotos/sportKleding/trui.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 3", "Trek een sport shirt aan.", "assets/img/Stappenplanfotos/sportKleding/sportjas.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 4", "Leg uw trui terug in de kast.", "assets/img/Stappenplanfotos/sportKleding/kast.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 5", "Trek uw broek uit.", "assets/img/Stappenplanfotos/sportKleding/broek.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 6", "Trek uw joggingbroek aan.", "assets/img/Stappenplanfotos/sportKleding/sportbroek.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 7", "Leg uw broek terug in de kast.", "assets/img/Stappenplanfotos/sportKleding/kast.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("Stap 8", "U bent klaar om te gaan sporten.", "assets/img/Stappenplanfotos/sportKleding/ready.jpg"));
            sportkleding.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var strijken = new stappenplanmodel_1.Stappenplan("Strijken", "assets/img/Stappenplanfotos/Strijken/strijkijzer.jpg");
            strijken.addStep(new stapmodel_1.StapModel("Stap 1", "Stop stekker van de strijkijzer in het stopcontact.", "assets/img/Stappenplanfotos/Strijken/stopcontact.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 2", "Zet de draaiknop op de juiste temperatuur.", "assets/img/Stappenplanfotos/Strijken/draaiknop.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 3", "Wacht een paar minuten otdat strijkijzer warm is.", "assets/img/Stappenplanfotos/Strijken/strijkijzer.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 4", "Pak een kledingstuk en leg het op de strijkplank.", "assets/img/Stappenplanfotos/Strijken/strijkplank.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 5", "Strijk de rechter mouw.", "assets/img/Stappenplanfotos/Strijken/mouw.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 6", "Strijk de linker mouw.", "assets/img/Stappenplanfotos/Strijken/mouw2.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 7", "Strijk de achterkant van het kledingstuk.", "assets/img/Stappenplanfotos/Strijken/achterkant.png"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 8", "Strijk de voorkant van het kledingstuk.", "assets/img/Stappenplanfotos/Strijken/voorkant.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 9", "Zet het strijkijzer uit en leg het terug.", "assets/img/Stappenplanfotos/Strijken/strijkijzer2.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("Stap 10", "Hang het kledingstuk aan een kleerhanger.", "assets/img/Stappenplanfotos/Strijken/kleerhanger.jpg"));
            strijken.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var kamerOpruimen = new stappenplanmodel_1.Stappenplan("Kamer opruimen", "assets/img/auping-zomer-slaapkamer-blauw.jpg");
            kamerOpruimen.addStep(new stapmodel_1.StapModel("Stap 1", "Ligt er kleding op de grond? Doe het dan in de wasmand.", "assets/img/Stappenplanfotos/KledingWassen/Mand-stap1.jpg"));
            kamerOpruimen.addStep(new stapmodel_1.StapModel("Stap 2", "Maak uw bed op door uw kussen bij uw hoofdeinde te leggen en uw laken gespreid op uw bed neer te leggen.", "assets/img/auping-zomer-slaapkamer-blauw.jpg"));
            kamerOpruimen.addStep(new stapmodel_1.StapModel("Stap 3", "Ligt er afval in uw kamer? Doe dit dan in de prullenbak.", "assets/img/Stappenplanfotos/kamerOpruimen/prullenbak.jpg"));
            kamerOpruimen.addStep(new stapmodel_1.StapModel("Stap 4", "Zet de stoelen terug bij de tafel.", "assets/img/Stappenplanfotos/kamerOpruimen/tafelEnStoelen.jpg"));
            kamerOpruimen.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var googleGebruiken = new stappenplanmodel_1.Stappenplan("Google gebruiken", "assets/img/Stappenplanfotos/GoogleGebruiken/googleLogo.jpg");
            googleGebruiken.addStep(new stapmodel_1.StapModel("Stap 1", "Open de browser op uw apparaat.", "assets/img/Stappenplanfotos/GoogleGebruiken/browser.png"));
            googleGebruiken.addStep(new stapmodel_1.StapModel("Stap 2", "Schrijf (google.com) hier.", "assets/img/Stappenplanfotos/GoogleGebruiken/link.png"));
            googleGebruiken.addStep(new stapmodel_1.StapModel("Stap 3", "Klik op (ok).", "assets/img/Stappenplanfotos/GoogleGebruiken/okKnop.jpg"));
            googleGebruiken.addStep(new stapmodel_1.StapModel("Stap 4", "Schrijf hier wat u wilt zoeken.", "assets/img/Stappenplanfotos/GoogleGebruiken/google.png"));
            googleGebruiken.addStep(new stapmodel_1.StapModel("Stap 5", "Druk op de knop zoeken.", "assets/img/Stappenplanfotos/GoogleGebruiken/googleZoeken.png"));
            googleGebruiken.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var bedVerschonen = new stappenplanmodel_1.Stappenplan("Bed verschonen ", "assets/img/Stappenplanfotos/Woman-changing-bedsheets.jpg");
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 1", "Haal de slopen van de kussens af en leg de kussens op een stoel (niet op de grond). De slopen doet u in de wasmand.", "assets/img/Stappenplanfotos/BedVerschonen/kussensloop.jpg"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 2", "Haal nu het dekbedovertrek van het dekbed af. Leg het dekbed ook op de stoel. Doe de overtrek van het dekbed ook in de wasmand.", "assets/img/Stappenplanfotos/BedVerschonen/"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 3", "Pak nu hoek voor hoek het matras op om het hoeslaken eraf te halen. Het hoeslaken kan ook meteen in de wasmand.", "assets/img/Stappenplanfotos/BedVerschonen/hoeslaken.JPG"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 4", "Nu doet u het schone hoeslaken op het bed. Doe dit ook weer hoek voor hoek en trek het daarna netjes, zodat het aan alle kanten ook langs de zijkant van het matras zit.", "assets/img/Stappenplanfotos/BedVerschonen/hoeslaken1.jpg"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 5", "Schud het dekbed even op en leg het uitgespreid op het bed. Doe het dekbedovertrek binnenste buiten en pak nu aan de binnenkant eerst de twee punten van de korte zijde van het dekbedovertrek.", "assets/img/Stappenplanfotos/BedVerschonen/dekbedopmaken"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 6", "Met uw handen nog aan de binnenkant in de punten van de dekbedhoes, pakt u nu twee hoeken van de korte zijde van het dekbed.", "assets/img/Stappenplanfotos/BedVerschonen/dekbedovertrekpunten"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 7", "Til het dekbed aan de twee hoeken hoog op en laat al schuddend de dekbedhoes over het dekbed heen zakken.", "assets/img/Stappenplanfotos/bedVerschonen/Bekbedovertrekschudden"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 8", "Leg het dekbed met de hoes eromheen weer op het bed en trek het nu helemaal netjes over het dekbed heen. Stop de instopstrook aan de achterkant onder het matras.", "assets/img/Stappenplanfotos/BedVerschonen/"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("Stap 9", "Pak de hoofdkussens, doe de schone slopen er omheen en leg ze aan het hoofdeinde.", "assets/img/Stappenplanfotos/bedVerschonen/"));
            bedVerschonen.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var ontbijtMaken = new stappenplanmodel_1.Stappenplan("Ontbijt maken ", "assets/img/Stappenplanfotos/OntbijtMaken/ontbijt.jpg");
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 1", "Pak een paar sneedjes brood.", "assets/img/Stappenplanfotos/OntbijtMaken/brood.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 2", "Leg ze op je bord.", "assets/img/Stappenplanfotos/OntbijtMaken/broodOpBoord.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 3", "Pak het beleg waar u zin in heeft.", "assets/img/Stappenplanfotos/OntbijtMaken/beleg.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 4", "Doe het beleg op het op uw brood.", "assets/img/Stappenplanfotos/OntbijtMaken/kaasOpBrood.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 5", "Pak een kom.", "assets/img/Stappenplanfotos/OntbijtMaken/kom.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 6", "Doe er fruit naar keuze in.", "assets/img/Stappenplanfotos/OntbijtMaken/druivenInKom.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("Stap 7", "Leg het bord en de kom op de tafel en begin met eten.", "assets/img/Stappenplanfotos/OntbijtMaken/etenOpTafel.jpg"));
            ontbijtMaken.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var vaatwasserUitruimen = new stappenplanmodel_1.Stappenplan("Vaatwasser uitruimen", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen0.jpg");
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 1", "Schuif de besteklade uit.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen1.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 2", "Neem de besteklade mee naar de bestekla, en leg al het bestek terug op zijn plek.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen2.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 3", "Zet alle glazen bij de andere glazen.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen3.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 4", "Zet alle pannen bij de andere pannen.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen4.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 5", "Zet alle bekers bij de andere bekers.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen5.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 6", "Zet alle borden bij de andere borden.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen6.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 7", "Staan er nog dingen in de vaatwasser? Vraag hulp bij een medewerker.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen7.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("Stap 8", "Doe de vaatwasserklep weer dicht.", "assets/img/Stappenplanfotos/VaatwasserUitruimen/VaatwasserUitruimen8.jpg"));
            vaatwasserUitruimen.addStep(new stapmodel_1.StapModel("", "Goed gedaan", randomGif()));
            var wizards = new Array();
            wizards.push(tandenPoetsen);
            wizards.push(kledingWassen);
            wizards.push(plantenWaterGeven);
            wizards.push(tafelDekken);
            wizards.push(sportkleding);
            wizards.push(strijken);
            wizards.push(kamerOpruimen);
            wizards.push(googleGebruiken);
            wizards.push(ontbijtMaken);
            wizards.push(bedVerschonen);
            wizards.push(vaatwasserUitruimen);
            let controller = new stappenplanoverviewcontroller_1.StappenplanOverviewController(wizards);
        }
    }
    exports.App = App;
});
function randomGif() {
    var randomNummer;
    randomNummer = Math.floor(Math.random() * myImg.length);
    console.log(myImg[randomNummer]);
    return myImg[randomNummer];
    ;
}
var myElement = document.getElementById('myImg'), myImg = [
    '/assets/gifs/01.gif',
    '/assets/gifs/02.gif',
    '/assets/gifs/03.gif',
    '/assets/gifs/04.gif',
    '/assets/gifs/05.gif',
    '/assets/gifs/06.gif',
    '/assets/gifs/07.gif',
    '/assets/gifs/08.gif',
    '/assets/gifs/09.gif',
    '/assets/gifs/10.gif',
    '/assets/gifs/11.gif',
    '/assets/gifs/12.gif',
    '/assets/gifs/13.gif',
    '/assets/gifs/14.gif',
    '/assets/gifs/15.gif',
    '/assets/gifs/16.gif',
    '/assets/gifs/17.gif',
    '/assets/gifs/18.gif',
    '/assets/gifs/19.gif'
];
console.log(randomGif());
function randomText() {
    var randomNummer;
    randomNummer = Math.floor(Math.random() * text.length);
    console.log(text[randomNummer]);
    return text[randomNummer];
    ;
}
var myElement = document.getElementById('text'), text = [
    'U heeft uw stappenplan volbracht! 🎊',
    'U bent nu klaar met uw stappenplan! 🎉 ',
    'proficiat! 👍🏻 ',
    'gefeliciteerd! 🥇 ',
    'Goed gedaan! 🏆',
];
class Login_Page {
    Login() {
        var a = 0;
        var txtuname = (document.getElementById('txtusername')).value;
        var txtpwd = (document.getElementById('txtpasswrd')).value;
        var bttnLogin = document.getElementById('login44');
    }
}
window.onload = () => {
    var bttnLogin = document.getElementById('login');
    var obj = new Login_Page();
    bttnLogin.onclick = function () {
        obj.Login();
    };
};
//# sourceMappingURL=app.js.map