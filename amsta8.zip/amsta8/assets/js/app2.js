var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
define("controllers/controller", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Controller = (function () {
        function Controller() {
            this.setup();
        }
        return Controller;
    }());
    exports.Controller = Controller;
});
define("utils/testutils", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var TestUtils = (function () {
        function TestUtils() {
        }
        TestUtils.isThisWorking = function () {
            return "Test test 123";
        };
        return TestUtils;
    }());
    exports.TestUtils = TestUtils;
});
define("components/test-button/test-button", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var TestButton = (function () {
        function TestButton(text) {
            this.text = text;
        }
        TestButton.prototype.setOnClick = function (callback) {
            this.onClickCallback = callback;
        };
        TestButton.prototype.getView = function () {
            var _this = this;
            var template = "<button>" + this.text + "</button>";
            return $(template)
                .on("click", function (e) { return _this.onClickCallback(e); });
        };
        return TestButton;
    }());
    exports.TestButton = TestButton;
});
define("controllers/maincontroller", ["require", "exports", "controllers/controller", "utils/testutils", "components/test-button/test-button"], function (require, exports, controller_1, testutils_1, test_button_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var MainController = (function (_super) {
        __extends(MainController, _super);
        function MainController() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        MainController.prototype.setup = function () {
            var testButton = new test_button_1.TestButton("Click me");
            testButton.setOnClick(function (e) {
                alert(testutils_1.TestUtils.isThisWorking());
                $.get("/views/test.html").done(function (data) {
                    $("#test-button").append(data);
                });
            });
            $("#test-button").append(testButton.getView());
        };
        return MainController;
    }(controller_1.Controller));
    exports.MainController = MainController;
});
define("models/stapmodel", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var StapModel = (function () {
        function StapModel(title, description, imageUrl) {
            this.title = title;
            this.description = description;
            this.imageUrl = imageUrl;
        }
        return StapModel;
    }());
    exports.StapModel = StapModel;
});
define("models/stappenplanmodel", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var Stappenplan = (function () {
        function Stappenplan(title) {
            this.title = title;
            this.steps = new Array();
        }
        Stappenplan.prototype.addStep = function (step) {
            this.steps.push(step);
        };
        return Stappenplan;
    }());
    exports.Stappenplan = Stappenplan;
});
define("controllers/stappenplancontroller", ["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var StappenplanController = (function () {
        function StappenplanController(wizard) {
            this.wizard = wizard;
            this.stepIndex = 0;
            this.renderPage();
        }
        StappenplanController.prototype.renderPage = function () {
            var self = this;
            $.get("/views/stap.html").done(function (data) {
                $("#body").html(data);
                var step = self.wizard.steps[self.stepIndex];
                $("#body #title").html(step.title);
                $("#body #description").html(step.description);
                $("#body #image").attr("src", step.imageUrl);
                $("#body #previous").on("click", function () {
                    self.previousStep();
                    self.renderPage();
                    return false;
                });
                $("#body #next").on("click", function () {
                    self.nextStep();
                    self.renderPage();
                    return false;
                });
            });
        };
        StappenplanController.prototype.previousStep = function () {
            if (this.stepIndex != 0)
                this.stepIndex--;
        };
        StappenplanController.prototype.nextStep = function () {
            if (this.stepIndex != 6)
                this.stepIndex++;
        };
        return StappenplanController;
    }());
    exports.StappenplanController = StappenplanController;
});


define("app", ["require", "exports", "models/stappenplanmodel", "models/stapmodel", "controllers/stappenplancontroller"], function (require, exports, stappenplanmodelKledingWassen, stapmodelKledingWassen, stappenplancontrollerKledingWassen) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var App = (function () {
        function App() {
        }
        App.main = function () {
            var kledingWassen = new stappenplanmodelKledingWassen.Stappenplan("kledingWassen");
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 1", "Doe alle vieze bonte kleding in de wasmand.", "../../stappenplan/kleding-wassen/images/maand1.jpg"));
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 2", "Neem de wasmand mee en loop richting de wasmachine.", "../../stappenplan/kleding-wassen/images/2.jpg"));
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 3", "Stop de kleding in de wasmachine", "../../stappenplan/kleding-wassen/images/3.jpg"));
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 4", "Sluit de deur van de wasmachine", "../../stappenplan/kleding-wassen/images/4.jpg"));
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 5", " Doe het wasmiddel in het laatje", "../../stappenplan/kleding-wassen/images/5.jpg"));
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 6", " Doe het laatje dicht", "../../stappenplan/kleding-wassen/images/6.jpg"));
            kledingWassen.addStep(new stapmodelKledingWassen.StapModel("Stap 7", "Druk op deze knop om te starten met wassen", "../../stappenplan/kleding-wassen/images/7.jpg"));

            App.wizards = new Array();
            App.wizards.push(kledingWassen);
            var controller = new stappenplancontrollerKledingWassen.StappenplanController(this.wizards[0]);
        };
        return App;
    }());
    exports.App = App;
});


//# sourceMappingURL=app.js.map