import { StapModel } from "models/stapmodel";

export class Stappenplan {
    public title : string;
    public steps : StapModel[];
    public imageUrl : string;

    constructor(title : string, imageUrl : string) {
        this.title = title;
        this.steps = new Array();
        this.imageUrl = imageUrl;
    }

    public addStep(step : StapModel) : void {
        this.steps.push(step);
    }
}