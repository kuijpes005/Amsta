// Deze klasse kiest een random .gif bestand uit de array en returnt deze

function randomGif(): string {
    var randomNummer: number;
    randomNummer = Math.floor(Math.random() * myImg.length);
    console.log(myImg[randomNummer]);
    return myImg[randomNummer];;
}

var myElement = document.getElementById('myImg'),
    myImg = [
        '/assets/gifs/01.gif', // index number 0
        '/assets/gifs/02.gif', // index number 1
        '/assets/gifs/03.gif', // index number 2
        '/assets/gifs/04.gif', // index number 3 
        '/assets/gifs/05.gif', // index number 4
        '/assets/gifs/06.gif', // index number 5
        '/assets/gifs/07.gif', // index number 6
        '/assets/gifs/08.gif', // index number 7
        '/assets/gifs/09.gif', // index number 8
        '/assets/gifs/10.gif', // index number 9
        '/assets/gifs/11.gif', // index number 10
        '/assets/gifs/12.gif', // index number 11
        '/assets/gifs/13.gif', // index number 12
        '/assets/gifs/14.gif', // index number 13
        '/assets/gifs/15.gif', // index number 14
        '/assets/gifs/16.gif', // index number 15
        '/assets/gifs/17.gif', // index number 16
        '/assets/gifs/18.gif', // index number 17
        '/assets/gifs/19.gif' // index number 18
    ];

    console.log(randomGif());

    // Deze klasse kiest een random tekstbestand uit de array en returnt deze
    function randomText(): string {
        var randomNummer: number;
        randomNummer = Math.floor(Math.random() * text.length);
        console.log(text[randomNummer]);
        return text[randomNummer];;
    }

    var myElement = document.getElementById('text'),
    text = [
        'U heeft uw stappenplan volbracht! 🎊', // index number 0
        'U bent nu klaar met uw stappenplan! 🎉 ', // index number 1
        'proficiat! 👍🏻 ', // index number 2
        'gefeliciteerd! 🥇 ', // index number 3 
        'Goed gedaan! 🏆', // index number 4

    ];