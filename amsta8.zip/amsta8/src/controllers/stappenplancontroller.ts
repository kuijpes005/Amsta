import { Stappenplan } from "models/stappenplanmodel";
import { StappenplanOverviewController } from "./stappenplanoverviewcontroller";

export class StappenplanController {
    private stappenPlan: Stappenplan;
    private stepIndex: number;

    constructor(stappenPlan: Stappenplan) {
        this.stappenPlan = stappenPlan;
        this.stepIndex = 0;

        this.renderPage();
    }

    private renderPage(): void {
        var self = this;

        $.get("/views/stap.html").done(function (data: any) {
            $("#body").html(data);

            var step = self.stappenPlan.steps[self.stepIndex];
            
            if (self.stepIndex < 1) {
                $("#body #previous").hide();
            }
            else {
                $("#body #previous").show();
            }
            if (self.stepIndex < self.stappenPlan.steps.length - 1) {
                $("#body #next").show();
            }
            else {
                $("#body #next").hide();
            }
           
            $("#body #title").html(step.title);
            $("#body #description").html(step.description);
            $("#body #image").attr("src", step.imageUrl);

            $("#body #previous").on("click", function () {
                //$("#body #previous").hide();
                self.previousStep();
                self.renderPage();
                return false;
            });

            $("#body #next").click(function() {
                //$("#body #previous").show();
                self.nextStep();
                self.renderPage();
                return false;
            });

            self.setProgressbar();

        });

    }

    private previousStep(): void {
        if (this.stepIndex > 0) {
            this.stepIndex--;
        }
    }

    private nextStep(): void {
        if (this.stepIndex < this.stappenPlan.steps.length - 1) {
            this.stepIndex++;
        }
    }

    private setProgressbar(): void {    
        let totalSteps = this.stappenPlan.steps.length;
        let currentStep = this.stepIndex;
        
        for (let iBullet = 0; iBullet < totalSteps; iBullet++) {
            //voor elke stap wordt een bullet gemaakt
            let bullet = $('<a href="#" data-i="' + iBullet + '"></a>').text(iBullet + 1);
            let segmentSize = iBullet * 100 / (totalSteps - 1);

            //Het percentage van de huidige stap, gedeeld door max steps
            bullet.css('left', segmentSize + '%');

            //Bij de huidige stap wordt een class active toegevoegd aan de bullet
            if(iBullet <= currentStep) {
                    bullet.addClass("current");
                }
            
            //Wanneer de stappen al gedaan zijn..
            if(currentStep > iBullet) {
                bullet.removeClass("current").addClass("done");
            };

            //Bullet wordt toegevoegd aan de bar
            $(".progress-bullets").append(bullet);
        }

        let totalSize = (currentStep / (totalSteps - 1) * 100);

        console.log(totalSize);

        $(".progress-bar").css("width", totalSize + "%");
    }

}