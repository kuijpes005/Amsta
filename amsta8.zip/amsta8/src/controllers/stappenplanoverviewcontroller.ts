import { Stappenplan } from "models/stappenplanmodel";
import { StappenplanController } from "./stappenplancontroller";

export class StappenplanOverviewController {
    private wizards: Stappenplan[];

    constructor(wizards: Stappenplan[]) {
        this.wizards = wizards;

        this.renderPage();
    }

    private renderPage(): void {
        $("#stappenplannen").empty();

        
        var row = $("<div class=row>");
        
        for(var i = 0; i < this.wizards.length; i++) {
            var wizard = this.wizards[i];
            var div = $("<div class=col-md-4 >")

            var h3 = $("<h3>")
                .text(wizard.title)
                .data("wizard", wizard)
                .on("click", function() {
                    let controller: StappenplanController = new StappenplanController($(this).data("wizard"));
                });
            var img = $("<img class=img-thumbnail>")
            //$("#body #image")
            .attr("src", wizard.imageUrl)
            .data("wizard", wizard)
            .on("click", function() {
                let controller: StappenplanController = new StappenplanController($(this).data("wizard"));
            });
            //.text(wizard.imageUrl)
            //.attr("wizard", wizard)

            row.append(div);            
            div.append(img);
            div.append(h3);            
        }
        
        $("#stappenplannen").append(row);
    }
}