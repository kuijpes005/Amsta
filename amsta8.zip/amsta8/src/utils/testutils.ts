export class TestUtils {
    
    public static isThisWorking(): string {
        return "Test test 123";
    }
}